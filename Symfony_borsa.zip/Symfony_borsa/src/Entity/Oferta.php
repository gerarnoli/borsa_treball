<?php

namespace App\Entity;

use App\Repository\OfertaRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=OfertaRepository::class)
 */
class Oferta
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $titol;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $descripcio;

    /**
     * @ORM\Column(type="date", nullable=true)
     */
    private $data_publicacio;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $ubicacio;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $estat;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTitol(): ?string
    {
        return $this->titol;
    }

    public function setTitol(?string $titol): self
    {
        $this->titol = $titol;

        return $this;
    }

    public function getDescripcio(): ?string
    {
        return $this->descripcio;
    }

    public function setDescripcio(?string $descripcio): self
    {
        $this->descripcio = $descripcio;

        return $this;
    }

    public function getDataPublicacio(): ?\DateTimeInterface
    {
        return $this->data_publicacio;
    }

    public function setDataPublicacio(?\DateTimeInterface $data_publicacio): self
    {
        $this->data_publicacio = $data_publicacio;

        return $this;
    }

    public function getUbicacio(): ?string
    {
        return $this->ubicacio;
    }

    public function setUbicacio(?string $ubicacio): self
    {
        $this->ubicacio = $ubicacio;

        return $this;
    }

    public function getEstat(): ?string
    {
        return $this->estat;
    }

    public function setEstat(?string $estat): self
    {
        $this->estat = $estat;

        return $this;
    }
}
